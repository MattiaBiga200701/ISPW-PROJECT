package it.florentino.dark.timeplanapp.observer;


public interface Observer {

    void update();
}
